<?php

class MasterModel extends CI_Model
{
    public $userData;
    public $list_access;
    public $roles;
    public $temp;

    public function __construct()
    {
        $this->load->database();

        if ($this->session->has_userdata('user_data'))
		$this->userData = $this->session->userdata('user_data');
		
		//else
		//return redirect('login', 'Location');
	
        if($this->uri->segment(1)=='cronjob'){
            $this->list_access = [
                'transfer_cabang'=>[
                    'p_t_cabang'
                ]
            ];
        }else{
            if(!empty($this->userData)){
                if($this->userData->id_user_group>0){
                    $list_access = $this->db->select('slug_user_role as role,GROUP_CONCAT(action) as action')
                        ->join('user_role_action ura','uga.id_user_role_action=ura.id','left')
                        ->where('uga.id_user_group',$this->userData->id_user_group)
                        ->group_by('slug_user_role')
                        ->get('user_group_action uga')->result_array();
                    $this->list_access = array_combine(
                        array_map(function($v){
                            return $v['role'];
                        },$list_access),
                        array_map(function($v){
                            return explode(',',$v['action']);
                        },$list_access)
                    );
                }else{
                    $list_access = $this->db->select('slug_user_role as role,GROUP_CONCAT(action) as action')
                        ->group_by('slug_user_role')
                        ->get('user_role_action')->result_array();
                    $this->list_access = array_combine(
                        array_map(function($v){
                            return $v['role'];
                        },$list_access),
                        array_map(function($v){
                            return explode(',',$v['action']);
                        },$list_access)
                    );
                }
            }
        }
        $this->temp = [
            'all'=>[1,7,8,''],
            'user_group'=>[22],
            'approval_group'=>[3,5,6,9,10,13,14,15,16,17,18],
            'admin_cabang'=>[2],
            'branch'=>[20,21],
            'one'=>[4],
        ];
        $this->roles = [
            'ho' => [
                1,  //ADMIN
                7,  //FINANCE
                8,  //SUPER ADMIN
            ],
            'ho_division' => [
                5,  //SALES ADMIN HO
                6,  //APPROVAL PUSAT
                9,  //SM
                10, //ASS DIR
                12, //SEKERTARIS
                13, //PM
                14, //HRD
                15, //GA SUPERVISOR
                16, //DIR
                17, //BUSINESS DIRECTOR
                18, //PRESDIR
                20, //BKK CHECKER
                21, //BKK CHECKER & ACCOUNTING
            ],
            'branch' => [
                2,  //ADMIN CABANG
                3,  //APPROVAL CABANG
            ],
            'single' => [
                4,  //FIELD FORCE
            ],
        ];
    }

    public function getCity(){
        return $this->db->get('tbl_city')->result();
    }

    public function getDoctor($branch_id="", $ff_id=""){ 
        if(!empty($branch_id)){
            $this->db->where('branch_id',$branch_id);
        }
        if(!empty($ff_id)){
            $this->db->where('ff_id',$ff_id);
        }
        return $this->db->order_by('name','asc')->get('tbl_doctor')->result();
    }
	
	public function getDoctorExport()
	{
		$this->db->select('tbl_doctor.*,tbl_branch.name AS branch_name');
		$this->db->from('tbl_doctor');
		$this->db->join('tbl_branch', 'tbl_doctor.branch_id=tbl_branch.id', 'left');
		$this->db->order_by('name','asc');
		return $this->db->get()->result();
    }
	
	public function getDoctorDynamic($limit,$offset,$filter='')
    {
		$this->db->start_cache();
		$this->db->select('tbl_doctor.*,tbl_branch.name AS branch_name,tbl_field_force.name AS field_force_name');
		$this->db->from('tbl_doctor');
		
		if(!empty($filter['branch_id'])){
            if(is_array($filter['branch_id'])){
                $this->db->where_in('tbl_doctor.branch_id',$filter['branch_id']);
            }else{
                $this->db->where('tbl_doctor.branch_id',$filter['branch_id']);
            }
        }
        if(!empty($filter['field_force_id'])){
            $this->db->where('tbl_doctor.ff_id',$filter['field_force_id']);
        }
		
		if(!empty($filter['search_name']))
        $this->db->like('tbl_doctor.name',$filter['search_name']);
		
		$this->db->join('tbl_branch', 'tbl_doctor.branch_id=tbl_branch.id', 'left');
		$this->db->join('tbl_field_force', 'tbl_doctor.ff_id=tbl_field_force.id', 'left');
		
		$this->db->stop_cache();
		
		$total = $this->db->count_all_results();
		
		//bug ordernya ga kesave abis count result
		$this->db->order_by('tbl_doctor.name','asc');
		
		$this->db->limit($limit, $offset);
		$data = $this->db->get()->result_array();
		
		$this->db->flush_cache();
		
        return array($data,$total);
    }
	
    public function getDoctorById($id){
        return $this->db
            ->where('id', $id)
            ->get('tbl_doctor')
            ->row();
    }
    public function getNonDoctorById($id){
        return $this->db
            ->where('id', $id)
            ->get('tbl_non_doctor')
            ->row();
    }

    public function getNonDoctor($branch_id="", $ff_id=""){ 
        if(!empty($branch_id)){
            $this->db->where('branch_id',$branch_id);
        }
        if(!empty($ff_id)){
            $this->db->where('ff_id',$ff_id);
        }
        return $this->db->get('tbl_non_doctor')->result();
    }

    public function getBank()
    {
        return $this->db->order_by('name','asc')->get('tbl_bank')->result();
    }
    
    public function getBankById($id)
    {
        return $this->db->where('id', $id)->get('tbl_bank')->result();
    }
    
    public function saveBank($post)
    {
        $data = [
            'code'      => $post['code'],
            'name'      => $post['name'],
            'branch'    => $post['branch'],
            'city'      => $post['city']
        ];
        if(isset($post['id']) && $post['id']!="")
        {
            return $this->db->where('id', $post['id'])->update('tbl_bank', $data);
        }
        else
        {
            return $this->db->insert('tbl_bank', $data);
        }
    }

    public function getTaxNominatifById($id){
        return $this->db->get_where('tbl_tax_nominative',['id'=>$id])->row();
    }

    public function detailBank($id)
    {
        $query = $this->db->query("SELECT * FROM tbl_bank WHERE id='".$id."'");
        return $query->row();
    }

    public function detailDoctor($id)
    {
        $query = $this->db->query("SELECT * FROM tbl_doctor WHERE id='".$id."'");
        return $query->row();
    }

    public function detailNonDoctor($id)
    {
        $query = $this->db->query("SELECT * FROM tbl_non_doctor WHERE id='".$id."'");
        return $query->row();
    }

    public function deleteBank($id)
    {
        $this->db->where('id', $id);
         return $this->db->delete('tbl_bank');
    }
    public function getBranch(){
        $branch = (object)[];
        if($this->getAccess('filter_view','all')){
            $branch = $this->db->select('tb.*,tr.name as region,tr.name as region_name, tr.code as region_code')
            ->from('tbl_branch tb')
            ->join('tbl_region tr','tr.id=tb.region_id','left')
            ->group_by('tb.id')
            ->order_by('tb.name')
            ->get()->result();
        }else if($this->getAccess('filter_view','custom')){
            $list_branch = $this->db->get_where('user_group_branch',['id_user_group'=>$this->userData->id_user_group])->result_array();
            $list_department = $this->db->get_where('user_group_department',['id_user_group'=>$this->userData->id_user_group])->result_array();
            $list_division = $this->db->get_where('user_group_division',['id_user_group'=>$this->userData->id_user_group])->result_array();
            $department=[];
            if(empty($list_branch)){
                if(!empty($list_department) || !empty($list_division)){
                    if(empty($list_department)){
                        $list_department = $this->db->where_in('division',array_column($list_division,'division'))->get('tbl_department')->result_array();
                    }
                    $branch = $this->db->select('tb.*,tr.name as region,tr.name as region_name, tr.code as region_code')
                    ->from('tbl_branch tb')
                    ->join('tbl_region tr','tr.id=tb.region_id','left')
                    ->join('tbl_department_branch tdb','tb.id=tdb.branch_id')
                    ->join('tbl_department td','td.id=tdb.department_id')
                    ->where_in('td.id',array_column($list_department,'department_id'))
                    ->group_by('tb.id')
                    ->order_by('tb.name')
                    ->get()->result();
                }
            }else{
                $branch = $this->db->select('tb.*,tr.name as region,tr.name as region_name, tr.code as region_code')
                ->from('tbl_branch tb')
                ->join('tbl_region tr','tr.id=tb.region_id','left')
                ->join('tbl_department_branch tdb','tb.id=tdb.branch_id')
                ->join('tbl_department td','td.id=tdb.department_id')
                ->where_in('tb.id',array_column($list_branch,'branch_id'))
                ->group_by('tb.id')
                ->order_by('tb.name')
                ->get()->result();
            }
        }else if($this->getAccess('filter_view','approver')){
            $branch = $this->db->select('ab.id_branch')
            ->from('user_approval_group uag')
            ->join('approval_group ag','ag.id=uag.id_approval_group')
            ->join('approval_branch ab','ag.id=ab.id_approval_group')
            ->where('uag.id_user',$this->userData->id)
            ->group_by('ab.id_branch')
            ->get()->result_array();
			
			if (!empty($branch))
			{
				$branch = array_column($branch,'id_branch');
				$branch = $this->db->select('tb.*,tr.name as region,tr.name as region_name, tr.code as region_code')
				->from('tbl_branch tb','tb.id=ab.id_branch')
				->join('tbl_region tr','tr.id=tb.region_id','left')
				->where_in('tb.id',$branch)
				->order_by('tb.name')
				->get()->result();
			}
        }
		else if($this->getAccess('filter_view','admin_cabang')){
            $branch = $this->db->select('tb.*,tr.name as region,tr.name as region_name, tr.code as region_code')
            ->from('tbl_branch tb')
            ->join('tbl_region tr','tr.id=tb.region_id','left')
            ->where('tb.sales_admin_id',$this->userData->id)
            ->or_where('tb.branch_cashier_id',$this->userData->id)
            ->group_by('tb.id')
            ->order_by('tb.name')
            ->get()->result();
        }else if($this->getAccess('filter_view','related_data')){
            $branch = $this->db->select('tb.*,tr.name as region,tr.name as region_name, tr.code as region_code')
            ->from('tbl_branch tb')
            ->join('tbl_region tr','tr.id=tb.region_id','left')
            ->where('tb.id',$this->userData->branch_id)
            ->group_by('tb.id')
            ->order_by('tb.name')
            ->get()->result();
        }
        return $branch;
    }
    public function getBranchArray(){
        $branch = [];
        if($this->getAccess('filter_view','all')){
            $branch = $this->db->select('tb.*,tr.name as region,tr.name as region_name, tr.code as region_code')
            ->from('tbl_branch tb')
            ->join('tbl_region tr','tr.id=tb.region_id','left')
            ->group_by('tb.id')
            ->order_by('tb.name')
            ->get()->result_array();
        }else if($this->getAccess('filter_view','custom')){
            $list_branch = $this->db->get_where('user_group_branch',['id_user_group'=>$this->userData->id_user_group])->result_array();
            $list_department = $this->db->get_where('user_group_department',['id_user_group'=>$this->userData->id_user_group])->result_array();
            $list_division = $this->db->get_where('user_group_division',['id_user_group'=>$this->userData->id_user_group])->result_array();
            $department=[];
            if(empty($list_branch)){
                if(!empty($list_department) || !empty($list_division)){
                    if(empty($list_department)){
                        $list_department = $this->db->where_in('division',array_column($list_division,'division'))->get('tbl_department')->result_array();
                    }
                    $branch = $this->db->select('tb.*,tr.name as region,tr.name as region_name, tr.code as region_code')
                    ->from('tbl_branch tb')
                    ->join('tbl_region tr','tr.id=tb.region_id','left')
                    ->join('tbl_department_branch tdb','tb.id=tdb.branch_id')
                    ->join('tbl_department td','td.id=tdb.department_id')
                    ->where_in('td.id',array_column($list_department,'department_id'))
                    ->group_by('tb.id')
                    ->order_by('tb.name')
                    ->get()->result_array();
                }
            }else{
                $branch = $this->db->select('tb.*,tr.name as region,tr.name as region_name, tr.code as region_code')
                ->from('tbl_branch tb')
                ->join('tbl_region tr','tr.id=tb.region_id','left')
                ->join('tbl_department_branch tdb','tb.id=tdb.branch_id')
                ->join('tbl_department td','td.id=tdb.department_id')
                ->where_in('tb.id',array_column($list_branch,'branch_id'))
                ->group_by('tb.id')
                ->order_by('tb.name')
                ->get()->result_array();
            }
            if(empty($branch)){
                return [
                    'list_branch'=>$list_branch,
                    'list_department'=>$list_department,
                    'list_division'=>$list_division,
                ];
            }
        }else if($this->getAccess('filter_view','approver')){
            $branch = $this->db->select('ab.id_branch')
            ->from('user_approval_group uag')
            ->join('approval_group ag','ag.id=uag.id_approval_group')
            ->join('approval_branch ab','ag.id=ab.id_approval_group')
            ->where('uag.id_user',$this->userData->id)
            ->group_by('ab.id_branch')
            ->get()->result_array();
			
			if (!empty($branch))
			{
				$branch = array_column($branch,'id_branch');
				$branch = $this->db->select('tb.*,tr.name as region,tr.name as region_name, tr.code as region_code')
				->from('tbl_branch tb','tb.id=ab.id_branch')
				->join('tbl_region tr','tr.id=tb.region_id','left')
				->where_in('tb.id',$branch)
				->order_by('tb.name')
				->get()->result_array();
			}

        }else if($this->getAccess('filter_view','admin_cabang')){
            $branch = $this->db->select('tb.*,tr.name as region,tr.name as region_name, tr.code as region_code')
            ->from('tbl_branch tb')
            ->join('tbl_region tr','tr.id=tb.region_id','left')
            ->where('tb.sales_admin_id',$this->userData->id)
            ->or_where('tb.branch_cashier_id',$this->userData->id)
            ->group_by('tb.id')
            ->order_by('tb.name')
            ->get()->result_array();
        }else if($this->getAccess('filter_view','related_data')){
            $branch = $this->db->select('tb.*,tr.name as region,tr.name as region_name, tr.code as region_code')
            ->from('tbl_branch tb')
            ->join('tbl_region tr','tr.id=tb.region_id','left')
            ->where('tb.id',$this->userData->branch_id)
            ->group_by('tb.id')
            ->order_by('tb.name')
            ->get()->result_array();
        }
        return $branch;
    }
    // public function getBranch(){
    //     $filter=[
    //         'all'=>$this->temp['all'],
    //         'user_group'=>$this->temp['user_group'],
    //         'approval_group'=>$this->temp['approval_group'],
    //         'admin_cabang'=>$this->temp['admin_cabang'],
    //         'branch'=>$this->temp['branch'],
    //         'one'=>$this->temp['one'],
    //     ];
    //     $option='';
    //     foreach ($filter as $key => $value) {
    //         if(in_array($this->userData->role_id,$value)){
    //             $option=$key;
    //         }
    //     }
    //     $branch = (object)[];
    //     switch ($option) {
    //         case 'all':
    //             $branch = $this->db->select('tb.*,tr.name as region_name, tr.code as region_code')
    //             ->from('tbl_branch tb')
    //             ->join('tbl_region tr','tr.id=tb.region_id','left')
    //             ->group_by('tb.id')
    //             ->order_by('tb.name')
    //             ->get()->result(); // result is all branch
    //         break;
    //         case 'user_group':
    //             $division = $this->db->select('ura.*')
    //             ->from('user_group ug')
    //             ->join('user_group_action uga','ug.id=uga.id_user_group')
    //             ->join('user_role_action ura','ura.id=uga.id_user_role_action')
    //             ->join('user_role ur','ur.slug=ura.slug_user_role')
    //             ->where('ug.id',$this->userData->id_user_group)
    //             ->where('ur.slug','division')
    //             ->get()->result_array();
    //             $division = array_column($division,'action');
    //             $branch = $this->db->select('tb.*,tr.name as region_name, tr.code as region_code')
    //             ->from('tbl_branch tb')
    //             ->join('tbl_region tr','tr.id=tb.region_id','left')
    //             ->join('tbl_department_branch tdb','tb.id=tdb.branch_id')
    //             ->join('tbl_department td','td.id=tdb.department_id')
    //             ->where_in('td.division',$division)
    //             ->group_by('tb.id')
    //             ->order_by('tb.name')
    //             ->get()->result(); // result is all branch on one or more division (may not all division)
    //         break;
    //         case 'approval_group':
    //             $branch = $this->db->select('ab.id_branch')
    //             ->from('user_approval_group uag')
    //             ->join('approval_group ag','ag.id=uag.id_approval_group')
    //             ->join('approval_branch ab','ag.id=ab.id_approval_group')
    //             ->where('uag.id_user',$this->userData->id)
    //             ->group_by('ab.id_branch')
    //             ->get()->result_array();
    //             $branch = array_column($branch,'id_branch');
    //             $branch = $this->db->select('tb.*,tr.name as region_name, tr.code as region_code')
    //             ->from('tbl_branch tb','tb.id=ab.id_branch')
    //             ->join('tbl_region tr','tr.id=tb.region_id','left')
    //             ->where_in('tb.id',$branch)
    //             ->order_by('tb.name')
    //             ->get()->result();
    //         break;
    //         case 'admin_cabang':
    //             $branch = $this->db->select('tb.*,tr.name as region_name, tr.code as region_code')
    //             ->from('tbl_branch tb')
    //             ->join('tbl_region tr','tr.id=tb.region_id','left')
    //             ->where('tb.sales_admin_id',$this->userData->id)
    //             ->or_where('tb.branch_cashier_id',$this->userData->id)
    //             ->group_by('tb.id')
    //             ->order_by('tb.name')
    //             ->get()->result(); // result is branch that assigned with user id
    //         break;
    //         case 'branch':
    //             $branch = $this->db->select('tb.*,tr.name as region_name, tr.code as region_code')
    //             ->from('tbl_branch tb')
    //             ->join('tbl_region tr','tr.id=tb.region_id','left')
    //             ->where('tb.id',$this->userData->branch_id)
    //             ->group_by('tb.id')
    //             ->order_by('tb.name')
    //             ->get()->result();
    //         break;
    //         case 'one':
    //             $branch = $this->db->select('tb.*,tr.name as region_name, tr.code as region_code')
    //             ->from('tbl_branch tb')
    //             ->join('tbl_region tr','tr.id=tb.region_id','left')
    //             ->where('tb.id',$this->userData->branch_id)
    //             ->group_by('tb.id')
    //             ->order_by('tb.name')
    //             ->get()->result();
    //         break;
    //     }
    //     return $branch;
    // }
    // public function getBranchArray(){
    //     $filter=[
    //         'all'=>$this->temp['all'],
    //         'user_group'=>$this->temp['user_group'],
    //         'approval_group'=>$this->temp['approval_group'],
    //         'admin_cabang'=>$this->temp['admin_cabang'],
    //         'branch'=>$this->temp['branch'],
    //         'one'=>$this->temp['one'],
    //     ];
    //     $option='';
    //     foreach ($filter as $key => $value) {
    //         if(in_array($this->userData->role_id,$value)){
    //             $option=$key;
    //         }
    //     }
    //     $branch = [];
    //     switch ($option) {
    //         case 'all':
    //             $branch = $this->db->select('tb.*,tr.name as region_name, tr.code as region_code')
    //             ->from('tbl_branch tb')
    //             ->join('tbl_region tr','tr.id=tb.region_id','left')
    //             ->group_by('tb.id')
    //             ->order_by('tb.name')
    //             ->get()->result_array(); // result is all branch
    //         break;
    //         case 'user_group':
    //             $division = $this->db->select('ura.*')
    //             ->from('user_group ug')
    //             ->join('user_group_action uga','ug.id=uga.id_user_group')
    //             ->join('user_role_action ura','ura.id=uga.id_user_role_action')
    //             ->join('user_role ur','ur.slug=ura.slug_user_role')
    //             ->where('ug.id',$this->userData->id_user_group)
    //             ->where('ur.slug','division')
    //             ->get()->result_array();
    //             $division = array_column($division,'action');
    //             $branch = $this->db->select('tb.*,tr.name as region_name, tr.code as region_code')
    //             ->from('tbl_branch tb')
    //             ->join('tbl_region tr','tr.id=tb.region_id','left')
    //             ->join('tbl_department_branch tdb','tb.id=tdb.branch_id')
    //             ->join('tbl_department td','td.id=tdb.department_id')
    //             ->where_in('td.division',$division)
    //             ->group_by('tb.id')
    //             ->order_by('tb.name')
    //             ->get()->result_array(); // result is all branch on one or more division (may not all division)
    //         break;
    //         case 'approval_group':
    //             $branch = $this->db->select('ab.id_branch')
    //             ->from('user_approval_group uag')
    //             ->join('approval_group ag','ag.id=uag.id_approval_group')
    //             ->join('approval_branch ab','ag.id=ab.id_approval_group')
    //             ->where('uag.id_user',$this->userData->id)
    //             ->group_by('ab.id_branch')
    //             ->get()->result_array();
    //             $branch = array_column($branch,'id_branch');
    //             $branch = $this->db->select('tb.*,tr.name as region_name, tr.code as region_code')
    //             ->from('tbl_branch tb','tb.id=ab.id_branch')
    //             ->join('tbl_region tr','tr.id=tb.region_id','left')
    //             ->where_in('tb.id',$branch)
    //             ->order_by('tb.name')
    //             ->get()->result_array();
    //         break;
    //         case 'admin_cabang':
    //             $branch = $this->db->select('tb.*,tr.name as region_name, tr.code as region_code')
    //             ->from('tbl_branch tb')
    //             ->join('tbl_region tr','tr.id=tb.region_id','left')
    //             ->where('tb.sales_admin_id',$this->userData->id)
    //             ->or_where('tb.branch_cashier_id',$this->userData->id)
    //             ->group_by('tb.id')
    //             ->order_by('tb.name')
    //             ->get()->result_array(); // result is branch that assigned with user id
    //         break;
    //         case 'branch':
    //             $branch = $this->db->select('tb.*,tr.name as region_name, tr.code as region_code')
    //             ->from('tbl_branch tb')
    //             ->join('tbl_region tr','tr.id=tb.region_id','left')
    //             ->where('tb.id',$this->userData->branch_id)
    //             ->group_by('tb.id')
    //             ->order_by('tb.name')
    //             ->get()->result_array();
    //         break;
    //         case 'one':
    //             $branch = $this->db->select('tb.*,tr.name as region_name, tr.code as region_code')
    //             ->from('tbl_branch tb')
    //             ->join('tbl_region tr','tr.id=tb.region_id','left')
    //             ->where('tb.id',$this->userData->branch_id)
    //             ->group_by('tb.id')
    //             ->order_by('tb.name')
    //             ->get()->result_array();
    //         break;
    //     }
    //     return $branch;
    // }
    /*
    public function getBranchArray(){
        $rolesHo = $this->roles['ho'];
        $rolesCabang = $this->roles['branch'];
        $roleSingleCabang = $this->roles['single'];
        if(!empty($this->userData)){
            $user = $this->userData;
            if($user->role_id==5){
                return $this->db->select('tb.*,tr.name as region')
                ->from('tbl_branch tb')
                ->join('tbl_region tr','tr.id=tb.region_id','left')
                ->join('approval_branch ab','ab.id_branch=tb.id')
                ->join('user_approval_group uag','uag.id_approval_group=ab.id_approval_group')
                ->where('uag.id_user',$user->id)
                ->get()->result_array();
            }else{
                $branch = $this->db->get_where('tbl_branch',['tbl_branch.id'=>$user->branch_id])->row();
                // Get Branch Data
                $this->db->select('tb.*,tr.name as region');
                $this->db->join('tbl_region tr','tr.id=tb.region_id','left')
                ->join('tbl_department_branch tdb','tb.id = tdb.branch_id')
                ->join('tbl_department td','td.id = tdb.department_id');
                if(in_array($user->role_id,$roleSingleCabang)){
                    $this->db->where('tb.id',$user->branch_id);
                }else if(in_array($user->role_id,$rolesCabang)){
                    $this->db->where('tb.sales_admin_id',$branch->sales_admin_id)
                    ->or_where('tb.branch_cashier_id',$branch->branch_cashier_id);
                }else if(in_array($user->role_id,$rolesHo)){
                    
                }
                $this->db->order_by('tb.name','asc');
                return $this->db->get('tbl_branch tb')->result_array();
            }
        }
        return [];
    }
    public function getBranch(){
        $rolesHo = $this->roles['ho'];
        $rolesHoDivision = $this->roles['ho_division'];
        $rolesCabang = $this->roles['branch'];
        $roleSingleCabang = $this->roles['single'];
        if(!empty($this->userData)){
            $user = $this->userData;
            if($user->role_id==5){
                return $this->db->select('tb.*')->from('tbl_branch tb')
                ->join('tbl_region tr','tr.id=tb.region_id','left')
                ->join('approval_branch ab','ab.id_branch=tb.id')
                ->join('user_approval_group uag','uag.id_approval_group=ab.id_approval_group')
                ->where('uag.id_user',$user->id)
                ->order_by('tb.name')
                ->get()->result();
            }else{
                $branch = $this->db->select('tb.*,td.division')
                ->join('tbl_department_branch tdb','tb.id = tdb.branch_id')
                ->join('tbl_department td','td.id = tdb.department_id')
                ->get_where('tbl_branch tb',['tb.id'=>$user->branch_id])->row();
                // Get Branch Data
                $this->db->select('tb.*,tr.name as region');
                $this->db->join('tbl_region tr','tr.id=tb.region_id','left')
                ->join('tbl_department_branch tdb','tb.id = tdb.branch_id')
                ->join('tbl_department td','td.id = tdb.department_id');
                if(in_array($user->role_id,$roleSingleCabang)){
                    $this->db->where('tb.id',$user->branch_id);
                }else if(in_array($user->role_id,$rolesCabang)){
                    $this->db->where('tb.sales_admin_id',$branch->sales_admin_id)
                    ->or_where('tb.branch_cashier_id',$branch->branch_cashier_id);
                }else if(in_array($user->role_id,$rolesHoDivision)){
                    $this->db->where('td.division',$branch->division);
                }
                // $this->db->order_by('tb.sub_register','asc');
                $this->db->order_by('tb.name','asc');
                return $this->db->get('tbl_branch tb')->result();
            }
        }
    }
    */
    public function getBranchByAdminArray(){
        $user_id = $this->userData->id;
        $role_id = $this->userData->role_id;
        $branch = $this->db->get_where('tbl_branch',['id'=>$this->userData->branch_id])->row();
        $this->db->select('tb.*,tr.name as region')
        ->from('tbl_branch tb')
        ->join('tbl_region tr','tr.id=tb.region_id','left');
        if(!($role_id==''||$role_id==8)){
            $this->db->where('branch_cashier_id',$user_id)
            ->or_where('sales_admin_id',$user_id);
        }else if(!empty($branch)){
            $this->db->where('branch_cashier_id',$branch->branch_cashier_id)
            ->or_where('sales_admin_id',$branch->sales_admin_id);
        }
        $this->db->order_by('tb.name');
        return $this->db->get()->result_array();
    }
    public function getBranchByAdmin()
    {
        $user_id = $this->userData->id;
        // $branch = $this->db->get_where('tbl_branch',['id'=>$this->userData->branch_id])->row();
        $branch = $this->db->query("SELECT * FROM tbl_branch WHERE id = '".$this->userData->branch_id."'")->row();
        $where_user = '';
        $query_user = $this->db->query("SELECT * from tbl_user where id='".$user_id."'")->row();
        if($query_user)
        {
            if(!($query_user->role_id =='' || $query_user->role_id == 8)){
                $where_user = "WHERE sales_admin_id = '".$user_id."' OR branch_cashier_id = '".$user_id."'";
            }else if(!empty($branch)){
                $where_user = "WHERE sales_admin_id = '".$branch->sales_admin_id."' OR branch_cashier_id = '".$branch->branch_cashier_id."'";
            }
        }else{
            if(!empty($branch)){
                $where_user = "WHERE sales_admin_id = '".$branch->sales_admin_id."' OR branch_cashier_id = '".$branch->branch_cashier_id."'";
            }
        }
        $query = $this->db->query("SELECT tbl_branch.*,tbl_region.name as region
                                    FROM tbl_branch
                                    LEFT JOIN tbl_region ON tbl_region.id = tbl_branch.region_id ".$where_user.
                                    "ORDER BY tbl_branch.name ASC");
        return $query->result();
    }

    public function saveBranch($post)
    {
        $data = [
            'code'                      => (isset($post['code']))?$post['code']:'',
			'bkk_code'                  => (isset($post['bkk_code']))?$post['bkk_code']:'',
            'name'                      => (isset($post['name']))?$post['name']:'',
            'region_id'                 => (isset($post['region']))?$post['region']:'',
            'email_cashier'             => (isset($post['email_cashier']))?$post['email_cashier']:'',
            'email_sa_ho'               => (isset($post['email_sa_ho']))?$post['email_sa_ho']:'',
            'bank_id'                   => (isset($post['bank_id']))?$post['bank_id']:'',
            'bank_account'              => (isset($post['bank_account']))?$post['bank_account']:'',
            'bank_account_holder'       => (isset($post['bank_account_holder']))?$post['bank_account_holder']:'',
            'sub_register'              => (isset($post['sub_register']))?$post['sub_register']:'',
            'code_account_branch'       => (isset($post['code_account_branch']))?$post['code_account_branch']:'',
            'sales_admin_id'            => (isset($post['sales_admin_id']))?$post['sales_admin_id']:'',
            'branch_cashier_id'         => (isset($post['branch_cashier_id']))?$post['branch_cashier_id']:''
        ];
		
		foreach ($data as $key=>$value)
		$data[$key] = trim($value);
		
		/*
		$data['email_cashier'] = trim($data['email_cashier']);
		$data['email_sa_ho'] = trim($data['email_sa_ho']);
		$data['bank_account'] = trim($data['bank_account']);
		$data['bank_account_holder'] = trim($data['bank_account_holder']);
		*/
		
		$branch = $this->getBranchByName($data['name']);
		
        if(isset($post['id']) && $post['id']!="")
        {
			$is_ok = false;
			
			if (empty($branch))
			$is_ok = true;
		
			else
			{
				if ($branch->id == $post['id'])
				$is_ok = true;
			}
			
			if ($is_ok)
			{
				$bank_account_prev = (isset($post['bank_account_prev']))?$post['bank_account_prev']:'';
				$bank_name = (isset($post['bank_name']))?$post['bank_name']:'';
				$bank_account = $data['bank_account'];
				$bank_account_holder = $data['bank_account_holder'];
				
				if (!empty($bank_account_prev) && !empty($bank_name) && !empty($bank_account) && !empty($bank_account_holder))
				{
					$newdata = array(
						'bank_name' => $bank_name,
						'bank_account' => $bank_account,
						'bank_account_holder' => $bank_account_holder
					);
					$this->db->where('bank_account', $bank_account_prev)->update('tbl_transaction_eapu', $newdata);
				}
				
				return $this->db->where('id', $post['id'])->update('tbl_branch', $data);
			}
        }
		
        else
        {
			if (empty($branch))
            return $this->db->insert('tbl_branch', $data);
        }
		
		return null;
    }
	
	public function importDoctor($data)
    {
		$doctor = $this->db
            ->where('code', $data['code'])
            ->where('name', $data['name'])
			->where('ff_id', $data['ff_id'])
			->get('tbl_doctor')
			->row();
		
		if (empty($doctor)) return $this->db->insert('tbl_doctor', $data);
		else return $this->db->where('id', $doctor->id)->update('tbl_doctor', $data);
    }

    public function saveDoctor($post)
    {
        if(isset($post['product_code']))
        {
            $product_code_sem = $post['product_code'];
            $product_code = '';
            foreach ($product_code_sem as $key => $value) {
                if(end($product_code_sem)==$value)
                {
                    $product_code .= $value;
                }
                else
                {
                    $product_code .= $value.';';
                }
            }
            $post['product_code'] = $product_code;
        }
        else
        {
            $post['product_code'] = '';
        }
        if(isset($post['id']) && $post['id']!="")
        {
            return $this->db->where('id', $post['id'])->update('tbl_doctor', $post);
        }
        else
        {
            return $this->db->insert('tbl_doctor', $post);
        }
    }

    public function saveNonDoctor($post)
    {
        if(isset($post['product_code']))
        {
            $product_code_sem = $post['product_code'];
            $product_code = '';
            foreach ($product_code_sem as $key => $value) {
                if(end($product_code_sem)==$value)
                {
                    $product_code .= $value;
                }
                else
                {
                    $product_code .= $value.';';
                }
            }
            $post['product_code'] = $product_code;
        }
        else
        {
            $post['product_code'] = '';
        }
        if(isset($post['id']) && $post['id']!="")
        {
            return $this->db->where('id', $post['id'])->update('tbl_non_doctor', $post);
        }
        else
        {
            return $this->db->insert('tbl_non_doctor', $post);
        }
    }

    public function detailBranch($id)
    {
        $query = $this->db->query("SELECT * FROM tbl_branch WHERE id='".$id."'")->row();
        $query_total_staff = $this->db->query("SELECT * FROM tbl_jumlah_staff WHERE branch_id='".$id."'
                                order by created_at desc limit 1")->row();
        if($query_total_staff)
        {
            $query->rm_am_coor = $query_total_staff->rm.' / '.$query_total_staff->am.' / '.$query_total_staff->coordinator;
            $query->kae_sm_nce = $query_total_staff->kae.' / '.$query_total_staff->sm.' / '.$query_total_staff->nce;
        }
        else
        {
            $query->rm_am_coor = '0 / 0 / 0';
            $query->kae_sm_nce = '0 / 0 / 0';
        }

        return $query;
    }

    public function deleteBranch($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('tbl_branch');
    }

    public function deleteDoctor($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('tbl_doctor');
    }

    public function deleteNonDoctor($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('tbl_non_doctor');
    }

    public function getRegion()
    {
        return $this->db->get('tbl_region')->result();
    }
    
    public function getRegionById($id)
    {
        return $this->db->where('id', $id)->get('tbl_region')->result();
    }

    public function getTypeMarketing()
    {
        return $this->db->get('tbl_type_marketing')->result();
    }
	
	public function getUser($without_ff=false)
	{
		if ($without_ff)
		$this->db->where('role_id !=', 4);
		
		$this->db->order_by('full_name', 'ASC');
		
		return $this->db->get('tbl_user')->result();
    }
	
	public function getUserById($id) {
        return $this->db->where('id', $id)->get('tbl_user')->row();
    }
	
    public function getDepartmentByName()
    {
       $query = $this->db->get('tbl_department')->result();
       foreach ($query as $value)
       {
            $query_branch = $this->db->query("SELECT tbl_department_branch.*,
                                tbl_branch.name as branch
                                FROM tbl_department_branch
                                LEFT JOIN tbl_branch ON tbl_branch.id = tbl_department_branch.branch_id
                                WHERE tbl_department_branch.department_id = '".$value->id."'
                                ")->result();
            $value->branch_name = '';
            foreach ($query_branch as $value1) {
               $branchName = $value1->branch;
               if(end($query_branch) == $value1)
               {
                    $value->branch_name .= $branchName;
               }
               else
               {
                    $value->branch_name .= $branchName.'; ';
               }

            }
       }
       return $query;
    }

    public function getDepartmentByDivName($div, $name)
    {
        return $this->db
            ->where('division', $div)
            ->where('name', $name)
            ->get('tbl_department')
            ->row();
    }

    public function getDepartmentBranch($branch_id='')
    {
		$sql = "SELECT tbl_department_branch.*,
                                tbl_department.name as department,
                                tbl_department.division as division,
                                tbl_branch.name as branch
                                FROM tbl_department_branch
                                LEFT JOIN tbl_department ON tbl_department.id = tbl_department_branch.department_id
                                LEFT JOIN tbl_branch ON tbl_branch.id = tbl_department_branch.branch_id
                                ";
		
		if (!empty($branch_id))
		$sql .= ' WHERE tbl_branch.id='.$branch_id;
		
        $query = $this->db->query($sql);
        return $query->result();
    }

    public function master_department($by=''){
        if(!empty($by)){
            $data = array();
            if($by=='name'){
                $data = $this->db->select("
                        td.id as department_id, 
                        CONCAT(td.division,' - ',td.name) as department, 
                        td.code as code, 
                        GROUP_CONCAT(CONCAT('[',tb.id,',\"',tb.name,'\"]')) as branch")
                    ->from('tbl_department td')
                    ->join('tbl_department_branch tdb','td.id = tdb.department_id')
                    ->join('tbl_branch tb','tdb.branch_id = tb.id')
                    ->group_by('tdb.department_id')
                    ->order_by('td.code')
                    ->get()
                    ->result();
            }elseif($by=='branch'){
                $data = $this->db->select("
                    tb.id as branch_id, 
                    tb.name as branch,
                    GROUP_CONCAT(CONCAT('[',td.id,',\"',td.division,' - ',td.name,'\",',td.code,']')) as department")
                    ->from('tbl_department td')
                    ->join('tbl_department_branch tdb','td.id = tdb.department_id')
                    ->join('tbl_branch tb','tdb.branch_id = tb.id')
                    ->group_by('tdb.branch_id')
                    ->order_by('tb.name')
                    ->get()
                    ->result();
            }
            return $data;
        }
    }

    public function saveDeptBranch($post)
    {
        $data = [
            'branch_id'                      => (isset($post['branch_id']))?$post['branch_id']:'',
            'department_id'                      => (isset($post['department_id']))?$post['department_id']:''
        ];
        if(isset($post['id']) && $post['id']!="")
        {
            return $this->db->where('id', $post['id'])->update('tbl_department_branch', $data);
        }
        else
        {
            return $this->db->insert('tbl_department_branch', $data);
        }
    }

    public function detailDeptBranch($id)
    {
        $query = $this->db->query("SELECT * FROM tbl_department_branch WHERE id='".$id."'");
        return $query->row();
    }

    public function deleteDeptBranch($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('tbl_department_branch');
    }

    public function saveDepartment($post)
    {
        $branch_id = '';
        foreach ($post['branch'] as $value) {
            if(end($post['branch']) == $value)
            {
                $branch_id .= $value;
            }
            else
            {
                $branch_id .= $value.';';
            }
        }
        $data = [
            'code'      => $post['code'],
            'name'      => $post['name'],
            'division'  => $post['division']
        ];
        if(isset($post['id']) && $post['id']!="")
        {
            if($this->db->where('id', $post['id'])->update('tbl_department', $data))
            {
                $this->db->where('department_id', $post['id']);
                if($this->db->delete('tbl_department_branch'))
                {
                    foreach ($post['branch'] as $value)
                    {
                        $data_branch = [
                            'branch_id'     => $value,
                            'department_id' => $post['id']
                        ];
                        $this->db->insert('tbl_department_branch', $data_branch);
                    }
                    return true;
                }

            }
        }
        else
        {
            if($this->db->insert('tbl_department', $data))
            {
                $id = $this->db->insert_id();
                foreach ($post['branch'] as $value)
                {
                    $data_branch = [
                        'branch_id'     => $value,
                        'department_id' => $id
                    ];
                    $this->db->insert('tbl_department_branch', $data_branch);
                }
                return true;
            }
        }
    }

    public function deleteDepartment($id)
    {
        $this->db->where('id', $id);
        if($this->db->delete('tbl_department'))
        {
            $this->db->where('department_id', $id);
            return $this->db->delete('tbl_department_branch');
        }
    }

    public function deleteKeywordAdmin($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('tbl_keyword_admin');
    }

    public function detailDepartment($id)
    {
        $query = $this->db->query("SELECT * FROM tbl_department WHERE id='".$id."'")->row();

        $query_branch = $this->db->query("SELECT *
                            FROM tbl_department_branch
                            WHERE department_id = '".$query->id."'")->result();
        $query->branch_id = '';
        foreach ($query_branch as $value1) {
           $branch_id = $value1->branch_id;
           if(end($query_branch) == $value1)
           {
                $query->branch_id .= $branch_id;
           }
           else
           {
                $query->branch_id .= $branch_id.';';
           }

        }
        return $query;
    }

    public function saveRegion($post)
    {
        $data = [
            'code'      => $post['code'],
            'name'      => $post['name'],
        ];
        if(isset($post['id']) && $post['id']!="")
        {
            return $this->db->where('id', $post['id'])->update('tbl_region', $data);
        }
        else
        {
            return $this->db->insert('tbl_region', $data);
        }
    }

    public function deleteRegion($id)
    {
        $this->db->where('id', $id);
         return $this->db->delete('tbl_region');
    }

    public function detailRegion($id)
    {
        $query = $this->db->query("SELECT * FROM tbl_region WHERE id='".$id."'");
        return $query->row();
    }

    public function saveBranchSalesAdm($post)
    {
        $data = [
            'branch_id'      => $post['branch_id'],
            'contact_id'     => $post['contact_id'],
        ];
        if(isset($post['id']) && $post['id']!="")
        {
            return $this->db->where('id', $post['id'])->update('tbl_branch_sales_admin', $data);
        }
        else
        {
            return $this->db->insert('tbl_branch_sales_admin', $data);
        }
    }

    public function deleteBranchSalesAdm($id)
    {
        $this->db->where('id', $id);
         return $this->db->delete('tbl_branch_sales_admin');
    }

    public function detailBranchSalesAdm($id)
    {
        $query = $this->db->query("SELECT * FROM tbl_branch_sales_admin WHERE id='".$id."'");
        return $query->row();
    }

    public function getBranchSalesAdm()
    {
        return $this->db->get('tbl_branch_sales_admin')->result();
    }

    public function getContact()
    {
        return $this->db->get('tbl_contact')->result();
    }

    public function getNameBranch($id)
    {
        $query = $this->db->query("SELECT * FROM tbl_branch WHERE id='".$id."'")->row();
        if($query)
        {
            return $query->name;
        }
        else
        {
            return "";
        }
    }

    public function getTypeMarketingById($id)
    {
        $query = $this->db->query("SELECT * FROM tbl_type_marketing WHERE id='".$id."'")->row();
        if($query)
        {
            return $query->name;
        }
        else
        {
            return "";
        }
    }
    public function getNameProduct($id)
    {
        $query = $this->db->query("SELECT * FROM tbl_product WHERE id='".$id."'")->row();
        if($query)
        {
            return $query->name;
        }
        else
        {
            return "";
        }
    }
    public function getNameContact($id)
    {
        $getContact = $this->db->query("SELECT * FROM tbl_contact WHERE id='".$id."'")->row();
        if($getContact)
        {
            $middle_name = (isset($getContact->middle_name))?$getContact->middle_name:'';
            $last_name = (isset($getContact->last_name))?$getContact->last_name:'';
           return $getContact->first_name.$middle_name.$last_name;
        }
        else
        {
            return "";
        }
    }

    public function getDivision()
    {
        $query = $this->db->query("SELECT * FROM tbl_keyword WHERE name='division'");
        return $query->row();
    }

    public function getReligion()
    {
        $query = $this->db->query("SELECT * FROM tbl_keyword WHERE name='agama'");
        return $query->row();
    }

    public function getDepartmentName()
    {
        $query = $this->db->query("SELECT * FROM tbl_keyword WHERE name='department'");
        return $query->row();
    }

    public function getListDepartmentById($id)
    {
        $query = $this->db->query("SELECT *,
                CONCAT(tbl_department.division,'-',tbl_department.name) as department, 
                tbl_department.id as id
            FROM tbl_department_branch
            LEFT JOIN tbl_department on tbl_department.id = tbl_department_branch.department_id
            WHERE tbl_department_branch.branch_id = '".$id."' GROUP BY tbl_department_branch.department_id");
        return $query->result();
    }

    public function getListDivision($id)
    {
        $query = $this->db->query("SELECT distinct(division) FROM tbl_department_branch
            LEFT JOIN tbl_department on tbl_department.id = tbl_department_branch.department_id
            WHERE tbl_department_branch.branch_id = '".$id."'");
        return $query->result();
    }

    public function getDepartment()
    {
        $branch = $this->getBranchArray();
        $department = [];
        if(!empty($branch)){
            $department = $this->db->where_in('branch_id',array_column($branch,'id'))->group_by('department_id')->get('tbl_department_branch')->result_array();
        }
        if(!empty($department)){
            $this->db->where_in('id',array_column($department,'department_id'));
        }
        return $this->db->select('td.*,CONCAT(division,"-",name) as department')->get('tbl_department td')->result();
    }
    public function getFFByBranchId($id='')
    {
		/*
        if(empty($id)){
            $id = $this->userData->branch_id;
            $query = $this->db->query("SELECT * FROM tbl_field_force WHERE branch_id = '".$id."'");
        }else{
            $query = $this->db->query("SELECT * FROM tbl_field_force WHERE branch_id = '".$id."'");
        }
		
		return $query->result();
		*/
		
		if(empty($id))
		$id = $this->userData->branch_id;
		
		return $this->db->where('branch_id', $id)
				->where('status !=', 0)
				->order_by('name','asc')->get('tbl_field_force')->result();
    }
    public function getTeamByBranchId($id)
    {
        $branch = $this->detailbranch($id);
        /*
		$branch_name = $branch->name;
		$filter_keyword = strtolower(substr($branch_name, -2));
        if($filter_keyword == 'll')
        {
            $filter_keyword = 'bg';
        }
		*/
		
		$branch_name = strtolower($branch->name);
		
		$filter_keyword = '';
		
		//bgteam,cnteam,dll
		$array_code = array('x','bg','by','uc','td','md','cn','ep','ga','le','me','mm','ms','oc','od','ca','onc','kam');
		
		foreach ($array_code as $val)
		{
			$pos = strpos($branch_name, $val, 3);
			
			if ($pos !== false)
			{
				if ($val == 'cn')
				$val = 'bg';
				
				$filter_keyword = $val;
				break;
			}
		}
		
		if (!empty($filter_keyword))
		{
			$name_team = $filter_keyword.'team';
			$query = $this->db->query("SELECT * FROM tbl_keyword WHERE name='".$name_team."'");
			return $query->row();
		}
		
		else
		return null;
    }
    public function getPosition()
    {
        $query = $this->db->query("SELECT * FROM tbl_keyword WHERE name='ff position'");
        return $query->row();
    }
	
	public function getPostingKeuangan() {
		return $this->db->order_by("nama_perkiraan", "asc")->get('tbl_posting_keuangan')->result_array();
	}
	
    public function getPostingKeuanganById($id){
        return $this->db->where('id',$id)->get('tbl_posting_keuangan')->row();
    }

    public function getPostingKeuanganByName($category_id, $name)
    {
        return $this->db
            ->where('category_id', $category_id)
            ->where('nama_perkiraan', $name)
            ->get('tbl_posting_keuangan')
            ->row();
    }

    public function getProductList($division)
    {
        $query = $this->db->query("SELECT *,tbl_product.alias as name FROM tbl_product
                            LEFT JOIN tbl_product_department on tbl_product_department.product_id = tbl_product.id
                            LEFT JOIN tbl_department on tbl_department.id = tbl_product_department.department_id
                            WHERE division='".$division."'");
        return $query->result();
    }
    public function getProduct()
    {
        return $this->db->get('tbl_product')->result();
    }
    public function getProductById($id)
    {
        return $this->db->where('id', $id)->get('tbl_product')->result();
    }
    public function getProductByName($name)
    {
        return $this->db
            ->where('name', $name)
            ->get('tbl_product')
            ->row();
    }
    public function getKeyword()
    {
        return $this->db->order_by("type", "asc")->get('tbl_keyword')->result();
    }

    public function getKeywordAdmin($filter='')
    {
        if(!empty($filter)){
            if(isset($filter['name'])){
                $this->db->where('name',$filter['name']);
            }
        }
        return $this->db->order_by("name", "asc")->get('tbl_keyword_admin')->result();
    }

    public function detailKeyword($id)
    {
        $query = $this->db->query("SELECT * FROM tbl_keyword WHERE id='".$id."'");
        return $query->row();
    }

    public function detailKeywordAdmin($id)
    {
        $query = $this->db->query("SELECT * FROM tbl_keyword_admin WHERE id='".$id."'");
        return $query->row();
    }

    public function saveKeyword($post)
    {
        $description = '';
        foreach ($post['list'] as $value) {
            if(end($post['list']) == $value)
            {
                $description .= $value;
            }
            else
            {
                $description .= $value.';';
            }
        }
        $data = [
            'description'  => $description,
        ];
        if(isset($post['id']) && $post['id']!="")
        {
            return $this->db->where('id', $post['id'])->update('tbl_keyword', $data);
        }
    }

    public function saveKeywordAdmin($post)
    {
        $description = '';
        foreach ($post['list'] as $value) {
            if(end($post['list']) == $value)
            {
                $description .= $value;
            }
            else
            {
                $description .= $value.';';
            }
        }
        $data = [
            'description'  => $description,
            'name'         => $post['keyword']
        ];
        if(isset($post['id']) && $post['id']!="")
        {
            return $this->db->where('id', $post['id'])->update('tbl_keyword_admin', $data);
        }
        else
        {
            return $this->db->insert('tbl_keyword_admin', $data);
        }
    }

    public function getNameDepartment($id)
    {
        $query = $this->db->query("SELECT * FROM tbl_department WHERE id='".$id."'")->row();
        if($query)
        {
            return $query->division.'-'.$query->name;
        }
        else
        {
            return "";
        }
    }

    public function getBranchById($id)
    {
        if (!empty($id)) {
            return $this->db
                ->where('id', $id)
                ->get('tbl_branch')
                ->row();
        }
    }
    public function getBranchByName($name)
    {
        return $this->db
            ->where('name', $name)
            ->get('tbl_branch')
            ->row();
    }
    public function getFieldForce($filter=''){
        if(!empty($filter['id'])){
            return $this->db->get_where('tbl_field_force',['id'=>$filter['id']])->result();
        }
        if(!empty($filter['branch_id'])){
            return $this->db->where('branch_id',$filter['branch_id'])->get('tbl_field_force')->result();
        }
        $rolesHo = [1,5,6,7,8,9,10,12,13,14,15,16,17,18,20,21];
        $rolesCabang = [2,3];
        $roleSingleCabang = [4];
        $user = $this->userData;
        if(!empty($user)){
            $branch = $this->db->get_where('tbl_branch',['id'=>$user->branch_id]);
            if(in_array($user->role_id,$rolesHo)){
            }
            if(in_array($user->role_id,$rolesCabang)){
                $list_branch = array_column($this->getBranchArray(),'id');
                $this->db->where_in('branch_id',$list_branch);
            }
            if(in_array($user->role_id,$roleSingleCabang)){
                $this->db->where('branch_id',$user->branch_id);
            }
			$this->db->where('status','1');
			$this->db->order_by('name','asc');
            return $this->db->get('tbl_field_force')->result();
        }
        return [];
    }
    public function getFieldForceById($id){
        if (!empty($id)) {
            return $this->db
                ->where('id', $id)
                ->get('tbl_field_force')
                ->row();
        }
    }
	public function getFieldForceNameById($id)
	{
		$name = '';
		
		$row = $this->db->where('id', $id)->get('tbl_field_force')->row();
		
        if (!empty($row))
		$name = $row->name;
		
		return $name;
    }
	public function getFieldForceNameByCode($code)
	{
        if (!empty($code))
		{
			$name = '';
			
			$result = $this->db->where('code', $code)->get('tbl_field_force')->row_array();
			
			if (!empty($result))
			$name = $result['name'];
			
			return $name;
        }
    }
    public function getFieldForceByAdvance($id,$get=''){
        $this->db->select('tff.*')->from('tbl_advance ta')
        ->join('tbl_transaction_eapu tte','tte.id=ta.id_apu')
        ->join('tbl_field_force tff','tff.id=tte.field_force_id')
        ->where('ta.id',$id);
        if(!empty($get)){
            return $this->db->get()->row($get);
        }else{
            return $this->db->get()->row();
        }
    }
    public function getFieldForceByBkk($id,$get=''){
        $this->db->select('tff.*')->from('tbl_bkk tbkk')
        ->join('tbl_transaction_eapu tte','tte.id=tbkk.id_apu')
        ->join('tbl_field_force tff','tff.id=tte.field_force_id')
        ->where('tbkk.id',$id);
        if(!empty($get)){
            return $this->db->get()->row($get);
        }else{
            return $this->db->get()->row();
        }
    }
    public function getFieldForceByNotadebet($id,$get=''){
        $this->db->select('tff.*')->from('nota_debet nd')
        ->join('tbl_field_force tff','tff.id=nd.field_force_id')
        ->where('nd.id',$id);
        if(!empty($get)){
            return $this->db->get()->row($get);
        }else{
            return $this->db->get()->row();
        }
    }

    public function getDepartmentById($id)
    {
        if (!empty($id)) {
            return $this->db
                ->where('id', $id)
                ->get('tbl_department')
                ->row();
        }
    }
    public function getDivisionById($department_id)
    {
        if (!empty($department_id)) {
            $data = $this->db->get_where('tbl_department',['id'=>$department_id])->row();
            if(!empty($data)){
            	$data = $data->division;
            }
            return $data;
        }
    }

    public function getJenisKendaraan()
    {
        $query = $this->db->query("SELECT * FROM tbl_keyword WHERE name='vehicle type'");
        return $query->row();
    }

    public function updateTotalStaff($post)
    {
        $data = [
            'branch_id'     => $post['branch_id'],
            'rm'            => $post['total_rm'],
            'am'            => $post['total_am'],
            'coordinator'   => $post['total_coor'],
            'kae'           => $post['total_kae'],
            'sm'            => $post['total_sm'],
            'nce'           => $post['total_nce'],
            'created_by'    => $this->userData->id
        ];

    return $this->db->insert('tbl_jumlah_staff', $data);

    }

    public function getHistoryTotalStaff($id)
    {
        $query = $this->db->query("SELECT tbl_jumlah_staff.* , tbl_user.username FROM tbl_jumlah_staff left join tbl_user on tbl_jumlah_staff.created_by = tbl_user.id WHERE tbl_jumlah_staff.branch_id='".$id."' order by created_at desc");
        return $query->result();
    }

    public function getBankHo()
    {
         return $this->db
                ->get('tbl_bank_ho')
                ->result();
    }

    public function saveBankHo($post)
    {
        $data = [
            'name'      => $post['name'],
            'register'    => $post['register'],
            'sub_register'      => $post['sub_register'],
            'type'      => $post['type'],
            'rekening_kas_cabang'      => $post['rekening_kas_cabang']
        ];
        if(isset($post['id']) && $post['id']!="")
        {
            return $this->db->where('id', $post['id'])->update('tbl_bank_ho', $data);
        }
        else
        {
            return $this->db->insert('tbl_bank_ho', $data);
        }
    }

    public function detailBankHo($id)
    {
        $query = $this->db->query("SELECT * FROM tbl_bank_ho WHERE id='".$id."'");
        return $query->row();
    }

    public function deleteBankHo($id)
    {
        $this->db->where('id', $id);
         return $this->db->delete('tbl_bank_ho');
    }
        
    public function importBank($data)
    {
        if (empty($data['id']))
        return false;
        
        else
        {
            $check = $this->db->get_where('tbl_bank',['id'=>$data['id']])->num_rows();
            if ($check==0)
            return $this->db->insert('tbl_bank', $data);
        
            else
            return $this->db->where('id', $data['id'])->update('tbl_bank', $data);
        }
    }
    
    public function importBranch($data)
    {
        if (empty($data['id']))
        return false;
        
        else
        {
            $check = $this->db->get_where('tbl_branch',['id'=>$data['id']])->num_rows();
            if ($check==0)
            return $this->db->insert('tbl_branch', $data);
        
            else
            return $this->db->where('id', $data['id'])->update('tbl_branch', $data);
        }
    }
    
    public function importProduct($data)
    {
        if (empty($data['id']))
        return false;
        
        else
        {
            $check = $this->db->get_where('tbl_product',['id'=>$data['id']])->num_rows();
            if ($check==0)
            return $this->db->insert('tbl_product', $data);
        
            else
            return $this->db->where('id', $data['id'])->update('tbl_product', $data);
        }
    }
    
    public function importRegion($data)
    {
        if (empty($data['id']))
        return false;
        
        else
        {
            $check = $this->db->get_where('tbl_region',['id'=>$data['id']])->num_rows();
            if ($check==0)
            return $this->db->insert('tbl_region', $data);
        
            else
            return $this->db->where('id', $data['id'])->update('tbl_region', $data);
        }
    }
    

    public function getObjective(){
        $objective = $this->db->select('*')
            ->where('type','objective')
            ->get('tbl_keyword')
            ->result_array();
        return $objective;
    }

    public function getUserRole()
    {
         return $this->db
                ->order_by('name', 'ASC')
                ->get('user_role')
                ->result();
    }
    
    public function getUserRoleArray()
    {
         return $this->db
                ->order_by('name', 'ASC')
                ->get('user_role')
                ->result_array();
    }
    
    public function saveUserRole($post)
    {
        $data = [
            'slug'      => $post['slug'],
            'name'      => $post['name']
        ];
        
        $this->db->where('slug_user_role', $post['slug'])->delete('user_role_action');
        
        if (!empty($post['action']) && !empty($post['action_name']))
        {
            $array_action = array();
            
            $array_slug = $post['action'];
            $array_name = $post['action_name'];
            
            for ($i=0; $i < count($array_slug); $i++)
            {
                array_push($array_action, array(
                    'slug_user_role' => $post['slug'],
                    'action' => trim($array_slug[$i]),
                    'name' => trim($array_name[$i])
                ));
            }
            
            if (!empty($array_action))
            $this->db->insert_batch('user_role_action', $array_action); 
        }
        
        if(isset($post['id']) && $post['id']!="")
        {
            return $this->db->where('slug', $post['id'])->update('user_role', $data);
        }
        else
        {
            return $this->db->insert('user_role', $data);
        }
    }

    public function detailUserRole($id)
    {
        $query = $this->db->query("SELECT * FROM user_role WHERE slug='".$id."'");
        return $query->row();
    }
    
    public function deleteUserRole($id)
    {
        $this->db->where('slug_user_role', $id)->delete('user_role_action');
        $this->db->where('slug', $id);
        return $this->db->delete('user_role');
    }
    
    public function getUserAction($id)
    {
        return $this->db
                ->where('slug_user_role', $id)
                ->order_by('name', 'ASC')
                ->get('user_role_action')
                ->result_array();
    }
    
    public function getUserActionBySlugAction($slug, $action)
    {
        return $this->db
            ->where('slug_user_role', $slug)
            ->where('action', $action)
            ->get('user_role_action')
            ->row_array();
    }
    
    public function getUserGroupAction($id_user_group)
    {
        return $this->db
                ->where('id_user_group', $id_user_group)
                ->get('user_group_action')
                ->result_array();
    }
    
    public function getUserGroup()
    {
         return $this->db
                ->where('id >', '0')
                ->order_by('name')
                ->get('user_group')
                ->result();
    }
    
    public function saveUserGroup($post)
    {
        $data = [
            'name'      => $post['name']
        ];
        if(isset($post['id']) && $post['id']!="")
        {
            $this->addUserAction($post['id'], $post);
            return $this->db->where('id', $post['id'])->update('user_group', $data);
        }
        else
        {
            $insert = $this->db->insert('user_group', $data);
            $this->addUserAction($this->db->insert_id(), $post);
            return $insert;
        }
    }
    
    private function addUserAction($id, $post)
    {
        $this->db->where('id_user_group', $id)->delete('user_group_action');
        
        if (!empty($post['action']))
        {
            $array_action = array();
            
            foreach ($post['action'] as $action)
            {
                array_push($array_action, array(
                    'id_user_group' => $id,
                    'id_user_role_action' => $action
                ));
            }
            
            if (!empty($array_action))
            $this->db->insert_batch('user_group_action', $array_action); 
        }
    }

    public function detailUserGroup($id)
    {
        $query = $this->db->query("SELECT * FROM user_group WHERE id='".$id."'");
        return $query->row();
    }

    public function deleteUserGroup($id)
    {
        if ($id > 0)
        {
            $this->db->where('id_user_group', $id)->delete('user_group_action');
            $this->db->where('id', $id);
            return $this->db->delete('user_group');
        }
        
        else
        return false;
    }

    public function isUserAllowed($id_user_group, $slug, $action=''){
        if ($id_user_group < 0){
            return true;
        }else{
            if(empty($action)){
                // $user_role = $this->db->select('*')
                //     ->join('user_role_action ura','uga.id_user_role_action=ura.id','left')
                //     ->where_in('uga.id_user_group',$id_user_group)
                //     ->group_by('uga.id_user_group')
                //     ->get('user_group_action uga')->row();
                $user_role = $this->db->select('slug_user_role')
                    ->join('user_role_action ura','uga.id_user_role_action=ura.id','left')
                    ->where_in('uga.id_user_group',$id_user_group)
                    ->get('user_group_action uga')->result_array();
                if(empty($user_role)){
                    return false;
                }else{
                    $user_role = array_column($user_role,'slug_user_role');
                    return in_array($slug,$user_role);
                    // return $user_role->slug_user_role==$slug;
                }
            }else{
                $user_action = $this->getUserActionBySlugAction($slug, $action);
                if (empty($user_action)){
                    return false;
                }else{
                    $this->db->select('*');
                    $this->db->from('user_group_action');
                    $this->db->where('id_user_group', $id_user_group);
                    $this->db->where('id_user_role_action', $user_action['id']);
                    if ($this->db->count_all_results() > 0){
                        return true;
                    }else{
                        return false;
                    }
                }
            }
        }

    }

    public function getBkkById($id){
        return $this->db->where('id',$id)->get('tbl_bkk')->row();
    }
    public function getListAccess($user_id=''){
        $user = $this->userData;
        if(!empty($user_id)){
            $user = $this->db->get_where('tbl_user',['id'=>$user_id])->row();
        }
        if(empty($user)){
            return [];
        }
        $list_access = $this->db->select('slug_user_role as role,GROUP_CONCAT(action) as action')
            ->join('user_role_action ura','uga.id_user_role_action=ura.id','left')
            ->where('uga.id_user_group',$user->id_user_group)
            ->group_by('slug_user_role')
            ->get('user_group_action uga')->result_array();
        return array_combine(
            array_map(function($v){
                return $v['role'];
            },$list_access),
            array_map(function($v){
                return explode(',',$v['action']);
            },$list_access)
        );
    }
    public function getAccess($role,$action='',$flag=''){
        if(is_array($role)){
            return array_intersect($role,array_keys($this->list_access));
        }
        if(empty($action)){
            return isset($this->list_access[$role]);
        }
        if(is_array($action)){
            // 
            if($flag){
                return count(array_diff($action,$this->list_access[$role]))==0;
            }else{
                return count(array_diff($action,$this->list_access[$role]))!=count($action);
            }
        }
        if(!isset($this->list_access[$role])){
            return false;
        }
        return in_array($action,$this->list_access[$role]);
    }
    public function is_advance_outstanding($advance_id){
        return $this->db->get_where('tbl_advance',['id'=>$advance_id,'id_bkk'=>0])->num_rows()?true:false;
    }
    public function countApuOutstanding($field_force_id){
        /*
		$counter = 0;
        $data['apu_sent'] = $this->db->select('id')
        ->where('state',7)
        ->where('field_force_id',$field_force_id)
        ->get('tbl_transaction_eapu')
        ->result_array();
		*/
		
		/*
        //$ctr_outstanding = $this->db->where_in('state',[0,1,2,3])
		$ctr_outstanding = $this->db->where_in('state',[1,2,3])
        ->where('field_force_id',$field_force_id)
        ->from('tbl_transaction_eapu')->count_all_results();
        
		//sent bukan dokter
		$ctr_sent = $this->db->where('state',7)
		//->join('tbl_transaction_eapu_info','tbl_transaction_eapu_info.id_eapu=tbl_transaction_eapu.id','left')
        ->where('field_force_id',$field_force_id)
		//->where('tbl_transaction_eapu_info.id_eapu IS NULL')
		->where('dokter_id',0)
		->where('non_dokter_id',0)
        ->from('tbl_transaction_eapu')->count_all_results();
		
		$counter = $ctr_outstanding+$ctr_sent;
		*/
		
		$counter = $this->db->where_in('state',[1,2,3,7])
        ->where('field_force_id',$field_force_id)
		->where('dokter_id',0)
		->where('non_dokter_id',0)
        ->from('tbl_transaction_eapu')->count_all_results();
		
		/*
        if(!empty($data['apu_sent'])){
            $data['apu_sent'] = array_column($data['apu_sent'],'id');
            $data['apu_sent_outstanding'] = $this->db->where_in('id_apu',$data['apu_sent'])
            ->where('id_bkk',0)
            ->get('tbl_advance')
            ->num_rows();
            $counter += $data['apu_sent_outstanding'];
        }
		*/
		
        return $counter;
    }
    public function countAdvanceOutstanding($field_force_id){
        $count_advance = $this->db->from('tbl_advance ta')
            ->join('tbl_transaction_eapu tte','ta.id_apu=tte.id')
            ->where('tte.field_force_id',$field_force_id)
            ->get()->num_rows();
        return $count_advance;
    }
    public function getFieldForceLimit($field_force_id){
        $keyword_limit = explode(';', $this->detailKeywordAdmin(6)->list);
        $field_force = $this->MasterModel->getFieldForceById($field_force_id);
        if($field_force->position=='FF'){
            return $keyword_limit[0];
        }else if($field_force->position=='AM'||$field_force->position=='RM'){
            return $keyword_limit[1];
        }else{
            return 0;
        }
    }
    public function canCreateAdvanceDisabled($id_apu){
        $this->load->model(['CashReportModel']);
        $limit_advance = 5; //limit advance
        $canCreate = true;
        $userId = $this->userData->id;

        $apu = $this->db->get_where('tbl_transaction_eapu',['id'=>$id_apu,'state'=>7,'created_by'=>$userId])->row();
        if(empty($apu)){
            $canCreate = false;
        }else{
            $keyword_limit = explode(';', $this->detailKeywordAdmin(6)->list);
            $field_force = $this->getFieldForceById($apu->field_force_id);
            if($field_force->position=='FF'){
                $limit_advance = $keyword_limit[0];
            }else if($field_force->position=='AM'||$field_force->position=='RM'){
                $limit_advance = $keyword_limit[1];
            }

            $have_advance = $this->db->get_where('tbl_advance',['id_apu'=>$id_apu])->num_rows();
            $have_bkk = $this->db->get_where('tbl_bkk',['id_apu'=>$id_apu])->num_rows();
            $count_advance = $this->db->from('tbl_advance ta')
                ->join('tbl_transaction_eapu tte','ta.id_apu=tte.id')
                ->where('tte.field_force_id',$apu->field_force_id)
                ->where('ta.id_bkk',0)
                ->get()->num_rows();
            $payment_type = $this->db->from('tbl_transaction_eapu tte')
                ->join('tbl_posting_keuangan tpk','tpk.id=tte.posting_keuangan_id')
                ->where('tpk.jenis_pembayaran',1)
                ->where('tte.id',$id_apu)
                ->get()->num_rows();
            
            $department = $this->getDepartmentById($apu->department_id);
            isset($department)?$department=$department->division:$department='';
            if($have_advance>0 || $have_bkk>0 || $payment_type==0){
                $canCreate =false;
            }
        }
        return $canCreate;
    }
    public function canCreateAdvance($id_apu){
        $this->load->model(['CashReportModel']);
        $limit_advance = 5; //limit advance
        $canCreate = true;
        $userId = $this->userData->id;
        $apu = $this->db->get_where('tbl_transaction_eapu',['id'=>$id_apu,'state'=>7,'created_by'=>$userId])->row();

        if(empty($apu)){
            $canCreate = false;
        }else{
            $keyword_limit = explode(';', $this->detailKeywordAdmin(6)->list);
            $field_force = $this->getFieldForceById($apu->field_force_id);
            if($field_force->position=='FF'){
                $limit_advance = $keyword_limit[0];
            }else if($field_force->position=='AM'||$field_force->position=='RM'){
                $limit_advance = $keyword_limit[1];
            }

            $have_advance = $this->db->get_where('tbl_advance',['id_apu'=>$id_apu])->num_rows();
            $have_bkk = $this->db->get_where('tbl_bkk',['id_apu'=>$id_apu])->num_rows();
            $count_advance = $this->db->from('tbl_advance ta')
                ->join('tbl_transaction_eapu tte','ta.id_apu=tte.id')
                ->where('tte.field_force_id',$apu->field_force_id)
                ->where('ta.id_bkk',0)
                ->get()->num_rows();
            $payment_type = $this->db->from('tbl_transaction_eapu tte')
                ->join('tbl_posting_keuangan tpk','tpk.id=tte.posting_keuangan_id')
                ->where('tpk.jenis_pembayaran',1)
                ->where('tte.id',$id_apu)
                ->get()->num_rows();
            $department = $this->getDepartmentById($apu->department_id);
            isset($department)?$department=$department->division:$department='';
            $cashCabang = $this->CashReportModel->getCash($apu->branch_id,$department);
            $checkCash = true;
            if($cashCabang>0){
                if($cashCabang>=$apu->jumlah){
                    $checkCash = false;
                }
            }
            $transfer_date = $this->db->select('transfer_date')->get_where('tbl_transfer_branch',['id'=>$apu->transfer_id])->row('transfer_date');
            //$hasBeenTransfered = time()>=strtotime($transfer_date);
			$hasBeenTransfered = true;
            $isExpiredApu = $apu->state == 6;
            //if($have_advance>0 || $have_bkk>0 || $payment_type==0 || $count_advance>=$limit_advance || $checkCash || $isExpiredApu || !$hasBeenTransfered){
			if($have_advance>0 || $have_bkk>0 || $payment_type==0 || $checkCash || $isExpiredApu || !$hasBeenTransfered){
                $canCreate =false;
            }
        }
        return $canCreate;
    }
    
    public function lock_field_force($field_force_id){
        // Lock Field Force
        $advance_outstanding = $this->db->from('tbl_advance ta')
            ->join('tbl_transaction_eapu tte','ta.id_apu=tte.id')
            ->where('tte.field_force_id',$field_force_id)
            ->where('ta.id_bkk',0)
            ->get()->result_array();
        $count_advance = count($advance_outstanding);
        
        $limit = explode(';', $this->MasterModel->detailKeywordAdmin(6)->list);
        
        $field_force = $this->getFieldForceById($field_force_id);
        
        if($field_force->position=='FF'){
            $limit = $limit[0];
        }else if($field_force->position=='AM'||$field_force->position=='RM'){
            $limit = $limit[1];
        }
        $expired_date = array_column($advance_outstanding,'expired_date');
        if(date('Y-m-d')>min($expired_date) || $count_advance>=$limit){
            return $this->db->update('tbl_field_force',['status'=>2],['id'=>$field_force_id]);
        }
        return false;
    }
    public function unlock_field_force($field_force_id){
        // Lock Field Force
        $advance_outstanding = $this->db->from('tbl_advance ta')
            ->join('tbl_transaction_eapu tte','ta.id_apu=tte.id')
            ->where('tte.field_force_id',$field_force_id)
            ->where('ta.id_bkk',0)
            ->get()->result_array();
        $count_advance = count($advance_outstanding);
        
        $limit = explode(';', $this->MasterModel->detailKeywordAdmin(6)->list);
        
        $field_force = $this->getFieldForceById($field_force_id);
        
        if($field_force->position=='FF'){
            $limit = $limit[0];
        }else if($field_force->position=='AM'||$field_force->position=='RM'){
            $limit = $limit[1];
        }

        $expired_date = array_column($advance_outstanding,'expired_date');
        if(date('Y-m-d')>min($expired_date)){
            return false;
        }else if($count_advance>=$limit){
            return false;
        }else{
            return $this->db->update('tbl_field_force',['status'=>1],['id'=>$field_force_id]);
        }
    }
    public function logged_data($data){
        $current_data = json_decode(file_get_contents(APPPATH.'/logs/alljob.json'));
        array_unshift($current_data, $data);
        $this->load->helper('file');
        return write_file(APPPATH.'/logs/alljob.json',json_encode($current_data));
    }
	
	public function nextApprover($id_eapu,$field=''){
		$data = '';
		if(!empty($id_eapu)){
	    	$data = $this->db->join('approval_route','tbl_user.id = approval_route.id_user')
	    		->where('id_eapu',$id_eapu)
	    		->where('is_approved',0)
	    		->order_by('position','asc')
	    		->get('tbl_user');
	    	if($data->num_rows()>0){
	    		if(!empty($field)){
		    		$data = $data->row()->$field;
	    		}else{
	    			$data = $data->row();
	    		}
	    	}else{
	    		$data = '';
	    	}
		}
		return $data;
    }
	
	public function getLastReason($id_eapu)
	{
		$data = '';
		
		if(!empty($id_eapu))
		{
	    	$result = $this->db->where('id_eapu',$id_eapu)
	    		->order_by('time_process','desc')
				->limit(1)
	    		->get('approval_history')->row_array();
			
			if (!empty($result))
			$data = $result['reason'];	
		}
		
		return $data;
    }
	
	public function isUserAdminTransfer($id_user)
    {
		$result = $this->db
            ->select('COUNT(approval_group_parent.weight) as ctr')
			->from('user_approval_group')
            ->join('approval_group', 'user_approval_group.id_approval_group=approval_group.id')
			->join('approval_group_parent', 'approval_group_parent.id=approval_group.id_approval_group_parent')
            ->where('user_approval_group.id_user', $id_user)
			->where('approval_group_parent.weight >', 10000)
            ->get()->row_array();
			
			if (empty($result['ctr']))
			return false;
		
			else
			return true;
    }
	
}